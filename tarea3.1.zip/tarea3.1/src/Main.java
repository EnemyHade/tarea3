import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

record Estudiante(String nombre, String curso, double nota1, double nota2, double nota3) {

    public double obtenerPromedio() {
        return (nota1 + nota2 + nota3) / 3.0;
    }
    public String obtenerEstado() {
        return obtenerPromedio() >= 4.0 ? "Aprobado" : "Reprobado";
    }
}

class Tarea3 {
    public static void main(String[] args) {
        List<Estudiante> baseDatos = cargarEstudiantes();
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        System.out.println("Bienvenido veamos que pasa y quien se queda");
        while (!salir) {
            System.out.println("\n MENÚ ");
            System.out.println("1. Mostrar Estudiantes y veamos su info");
            System.out.println("2. Menú de Calculadora y experimentar nota");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            String opcionStr = scanner.nextLine();
            int opcion = 0;
            try {
                opcion = Integer.parseInt(opcionStr);
            } catch (NumberFormatException e) {
                System.out.println("Error: Por favor escoja una opcion disponible.");
                continue;
            }
            switch (opcion) {
                case 1:
                    menuConsultaEstudiante(baseDatos, scanner);
                    break;
                case 2:
                    menuCalculadora(baseDatos, scanner);
                    break;
                case 3:
                    salir = true;
                    System.out.println("Gracias por no enseñarme quien se queda");
                    break;
                default:
                    System.out.println("Opción no válida. yapo escoja algo valido.");
            }
        }
        scanner.close();
    }

    private static void menuConsultaEstudiante(List<Estudiante> estudiantes, Scanner scanner) {
        boolean salirMenuConsulta = false;
        while (!salirMenuConsulta) {
            System.out.println("\n- Estado Académico delos Estudiantes -");
            System.out.printf("%-22s | %-16s| %-10s%n", "Nombre", "Curso", "estado");
            System.out.println("------------------------------------------------------");
            estudiantes.forEach(est -> {
                System.out.printf("%-22s | %-16s | %-10s%n",
                        est.nombre(),
                        est.curso(),
                        est.obtenerEstado()
                );
            });
            System.out.println("------------------------------------------------------");
            System.out.print("\nMencione al estudiante y veamos que esconde (o 'volver' retroceder): ");
            String nombreBuscado = scanner.nextLine().trim();
            if (nombreBuscado.equalsIgnoreCase("volver")) {
                salirMenuConsulta = true;
                continue;
            }
            Optional<Estudiante> estudianteEncontrado = estudiantes.stream()
                    .filter(e -> e.nombre().equalsIgnoreCase(nombreBuscado))
                    .findFirst();
            if (estudianteEncontrado.isPresent()) {
                Estudiante est = estudianteEncontrado.get();
                boolean volverSubMenu = false;

                while (!volverSubMenu) {
                    System.out.println("\n- Detalle del Estudiante -");
                    System.out.println("Nombre : " + est.nombre());
                    System.out.println("Curso  : " + est.curso());
                    System.out.println("Estado : " + est.obtenerEstado());
                    System.out.println("\nOpciones del estudiante:");
                    System.out.println("1. Ver sus notas detalladas");
                    System.out.println("2. Volver a la lista de estudiantes");
                    System.out.print("Seleccione una opción: ");
                    String subOpcion = scanner.nextLine();

                    if (subOpcion.equals("1")) {
                        System.out.println("\n--- Notas de " + est.nombre() + " ---");
                        System.out.printf("Nota 1   : %.1f%n", est.nota1());
                        System.out.printf("Nota 2   : %.1f%n", est.nota2());
                        System.out.printf("Nota 3   : %.1f%n", est.nota3());
                        System.out.printf("Promedio : %.1f%n", est.obtenerPromedio());
                        System.out.println("\nEnter para avanzar...");
                        scanner.nextLine();
                    } else if (subOpcion.equals("2")) {
                        volverSubMenu = true;
                    } else {
                        System.out.println("Opción inválida.");
                    }
                }
            } else {
                System.out.println("\nenserio clonando para tener un estudiante?.");
                System.out.println("Enter para volver a ver estudiantes y no clone.");
                scanner.nextLine();
            }
        }
    }

    private static void menuCalculadora(List<Estudiante> estudiantes, Scanner scanner) {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n- MENÚ CALCULADORA -");
            System.out.println("1. Calculadora Básica (+, -, *, /)");
            System.out.println("2. ver nota necesaria para examen final");
            System.out.println("3. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            String op = scanner.nextLine();

            switch (op) {
                case "1":
                    usarCalculadoraBasica(scanner);
                    break;
                case "2":
                    calcularNotaAprobacion(estudiantes, scanner);
                    break;
                case "3":
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida.porfavor no siga intentando buscar opciones malas");
            }
        }
    }

    private static void calcularNotaAprobacion(List<Estudiante> estudiantes, Scanner scanner) {
        System.out.print("\nIngrese el nombre del estudiante para la proyección: ");
        String nombre = scanner.nextLine().trim();
        Optional<Estudiante> optEst = estudiantes.stream()
                .filter(e -> e.nombre().equalsIgnoreCase(nombre))
                .findFirst();
        if (optEst.isPresent()) {
            Estudiante est = optEst.get();
            double n1 = est.nota1();
            double n2 = est.nota2();
            double n3 = est.nota3();
            double sumaNotas = n1 + n2 + n3;
            double notaNecesaria = 16.0 - sumaNotas;
            System.out.println("\n- Proyección de Examen para " + est.nombre() + " -");
            System.out.printf("Nota 1 actual : %.1f%n", n1);
            System.out.printf("Nota 2 actual : %.1f%n", n2);
            System.out.printf("Nota 3 actual : %.1f%n", n3);

            if (notaNecesaria > 7.0) {
                System.out.printf("¡Estamos mal! Necesita un %.1f en el Examen.%n", notaNecesaria);
                System.out.println("Ya que pasa del 7.0, dudo que puedas vivir.");
            } else if (notaNecesaria <= 1.0) {
                System.out.println("Ya tiene el ramo aprobado, para que vienes a preguntar.");
            } else {
                System.out.printf("Si quieres aprobar de panzaso, vas necesita un %.1f en el Examen.%n", notaNecesaria);
            }
            System.out.println("\nEnter para volver a calcurar...");
            scanner.nextLine();
        } else {
            System.out.println("Enserio, todo para experimenta y no quiere.");
        }
    }

    private static void usarCalculadoraBasica(Scanner scanner) {
        System.out.println("\n--- Calculadora Básica ---");
        try {
            System.out.print("Ingrese primer numero: ");
            double num1 = Double.parseDouble(scanner.nextLine());
            System.out.print("Ingrese la operación (+, -, *, /): ");
            String operacion = scanner.nextLine().trim();
            System.out.print("Ingrese segundo número: ");
            double num2 = Double.parseDouble(scanner.nextLine());
            double resultado = 0;
            boolean operacionValida = true;
            switch (operacion) {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0) {
                        System.out.println("Error: enserio dividir por cero.");
                        operacionValida = false;
                    } else {
                        resultado = num1 / num2;
                    }
                    break;
                default:
                    System.out.println("Operación no reconocida.");
                    operacionValida = false;
            }
            if (operacionValida) {
                System.out.println("Resultado: " + num1 + " " + operacion + " " + num2 + " = " + resultado);
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: fallo puso un valor que no es un número.");
        }
        System.out.println("Enter es avanzar.");
        scanner.nextLine();
    }

    private static List<Estudiante> cargarEstudiantes() {
        List<Estudiante> lista = new ArrayList<>();
        lista.add(new Estudiante("Juan Perez", "Matemáticas", 5.0, 6.0, 5.5));
        lista.add(new Estudiante("Maria Gonzalez", "Programación", 7.0, 6.5, 6.9));
        lista.add(new Estudiante("Pedro Rojas", "Física", 3.0, 4.0, 3.5));
        lista.add(new Estudiante("Ana Soto", "Matemáticas", 4.0, 4.0, 4.0));
        lista.add(new Estudiante("Carlos Silva", "Bases de Datos", 3.5, 4.2, 4.0));
        lista.add(new Estudiante("Laura Gomez", "Programación", 7.0, 7.0, 7.0));
        lista.add(new Estudiante("Diego Ramirez", "Física", 5.0, 5.5, 5.1));
        lista.add(new Estudiante("Sofia Vargas", "Inglés", 6.0, 6.2, 6.1));
        lista.add(new Estudiante("Luis Torres", "Matemáticas", 2.0, 3.0, 2.5));
        lista.add(new Estudiante("Elena Castro", "Bases de Datos", 4.5, 4.0, 5.0));
        lista.add(new Estudiante("Miguel Ortiz", "Programación", 5.8, 5.5, 6.1));
        lista.add(new Estudiante("Lucia Morales", "Física", 6.4, 6.0, 6.8));
        lista.add(new Estudiante("Jorge Herrera", "Inglés", 3.2, 3.0, 3.4));
        lista.add(new Estudiante("Paula Medina", "Matemáticas", 4.8, 5.0, 4.6));
        lista.add(new Estudiante("Andres Flores", "Bases de Datos", 5.0, 4.5, 5.5));
        lista.add(new Estudiante("Valeria Rios", "Programación", 6.9, 6.8, 7.0));
        lista.add(new Estudiante("Gabriel Castillo", "Física", 4.1, 4.0, 4.2));
        lista.add(new Estudiante("Camila Vega", "Inglés", 5.6, 5.4, 5.8));
        lista.add(new Estudiante("Fernando Fuentes", "Matemáticas", 3.8, 4.0, 3.6));
        lista.add(new Estudiante("Valentina Navarro", "Bases de Datos", 6.0, 6.0, 6.0));
        lista.add(new Estudiante("Pablo Contreras", "Programación", 4.3, 4.5, 4.1));
        lista.add(new Estudiante("Daniela Araya", "Física", 5.9, 6.0, 5.8));
        lista.add(new Estudiante("Ricardo Pizarro", "Inglés", 4.0, 3.8, 4.2));
        lista.add(new Estudiante("Antonia Espinoza", "Matemáticas", 6.5, 6.0, 7.0));
        lista.add(new Estudiante("Javier Valdes", "Bases de Datos", 2.8, 3.0, 2.6));
        lista.add(new Estudiante("Martina Salinas", "Programación", 5.4, 5.5, 5.3));
        lista.add(new Estudiante("Alejandro Cardenas", "Física", 6.7, 6.5, 6.9));
        lista.add(new Estudiante("Florencia Cortes", "Inglés", 4.9, 5.0, 4.8));
        lista.add(new Estudiante("Felipe Bravo", "Matemáticas", 3.0, 3.0, 3.0));
        lista.add(new Estudiante("Catalina Carrasco", "Bases de Datos", 5.1, 5.2, 5.0));
        return lista;
    }
}